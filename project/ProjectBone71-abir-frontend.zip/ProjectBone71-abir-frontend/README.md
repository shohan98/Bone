# ProjectBone71
Client: Head of producer (71 tv) youtube streaming based ott platform
